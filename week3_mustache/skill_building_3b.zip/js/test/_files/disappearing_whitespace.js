({
  bedrooms: true,
  total: 1
})
